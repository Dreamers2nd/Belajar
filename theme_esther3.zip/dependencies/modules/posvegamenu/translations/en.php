<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{posvegamenu}prestashop>posvegamenu_86f847149d50dca2220a90392cc3a237'] = 'More Categories';
$_MODULE['<{posvegamenu}prestashop>posvegamenu_41a1cf97729b0434826cc273cb4ac12c'] = 'Close Categories';

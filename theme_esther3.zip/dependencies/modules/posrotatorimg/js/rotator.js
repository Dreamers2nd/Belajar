$(document).ready(function(){
  $('#show_variations_selector').after('<div class="checkbox"><label><input type="checkbox" id="form_image_rotator" name="form_image" value="1"> Use rotator image function for this product</label></div>');
  console.log('123');
})
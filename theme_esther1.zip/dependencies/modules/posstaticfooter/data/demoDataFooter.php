<?php

class demoDataFooter
{
    public function initData()
    {
        $return = true;
        $languages = Language::getLanguages(true);
        $id_shop = Context::getContext()->shop->id;
        $id_hook_footerbefore = (int)Hook::getIdByName('displayFooterBefore');
        $id_hook_footerafter = (int)Hook::getIdByName('displayFooterAfter');
        $id_hook_footerbottom = (int)Hook::getIdByName('displayFooterBottom');
        $queries = [
            'INSERT INTO `'._DB_PREFIX_.'posstaticfooter` (`id_posstaticfooter`, `id_hook`, `position`, `width`, `type_content`, `name_module`, `content`,`active_title`) VALUES
                (1, '.$id_hook_footerbefore.', 1, 12, 1, 0, \'{"cms":[false],"product":[false],"static":[false]}\', 0),				
				(2, '.$id_hook_footerafter.', 2, 12, 0, 0, \'{"cms":["1","2","4","5"],"product":[false],"static":["contact","sitemap","stores","my-account"]}\', 1),
				(3, '.$id_hook_footerbottom.', 3, 6, 1, 0, \'{"cms":[false],"product":[false],"static":[false]}\', 0),
				(4, '.$id_hook_footerbottom.', 4, 6, 1, 0, \'{"cms":[false],"product":[false],"static":[false]}\', 0);'
        ];

        foreach (Language::getLanguages(true, Context::getContext()->shop->id) as $lang) {
            $queries[] = 'INSERT INTO `'._DB_PREFIX_.'posstaticfooter_lang` (`id_posstaticfooter`, `id_lang`, `name`, `html_content`, `custom_content`) VALUES
                (1, '.(int)$lang['id_lang'].', "About us", \'<div class="footer_about_us">
					<div class="logo_footer">
						<a href="#"><img src="/pos_esther/img/cms/logo_footer.png" alt=""></a>
					</div>
					<div class="desc_info">
						We are a team of designers and developers that create high quality Magento, Prestashop, Opencart.
					</div>
					<div class="hotline">
					<img src="/pos_esther/img/cms/hotline.png" alt="">
					<div class="content_hl"><span>Customer Support</span> <strong>(08) 123 456 789</strong></div>
					</div>
				</div>\', ""),
				(2, '.(int)$lang['id_lang'].', "Information", "", ""),
				(3, '.(int)$lang['id_lang'].', "Copyright Block", \'<div class="copyright">Copyright <i class="fa fa-copyright"></i> 2019 <a href="http://posthemes.com/">Posthemes</a>. All Rights Reserved</div>\', ""),
				(4, '.(int)$lang['id_lang'].', "Payment Block", \'<div class="payment"><img src="/pos_esther/img/cms/payment.png" alt="" class="img-responsive"></div>\', "")'
				
            ;
        }

        $queries[] = 'INSERT INTO `'._DB_PREFIX_.'posstaticfooter_shop` (`id_posstaticfooter`, `id_shop`) VALUES
                (1, 1),
                (2, 1),
                (3, 1),
                (4, 1)';

        foreach ($queries as $query) {
            $return &= Db::getInstance()->execute($query);
        }

        return $return;
    }
}
?>